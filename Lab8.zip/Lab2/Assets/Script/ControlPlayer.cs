﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlPlayer : MonoBehaviour
{
    public static bool isGameOver, grounded;//trạng thái nhân vật
    public float jumpHeight, speed;//nhảy cao và chạy
    private Animator player;
    int score = 0;
    public Text textScore;
    public GameObject enemy,particle;

    // Start is called before the first frame update
    void Start()
    {
        //ánh xạ
        player = GetComponent<Animator>();
        isGameOver = false;
        grounded = false;
        Time.timeScale = 1;//thời gian thực
        textScore = GameObject.Find("txtText").GetComponent<Text>();

    }

	private void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.gameObject.tag == "tien")
		{
            score++;
            Destroy(collision.gameObject);
            textScore.text = "Score:" + score.ToString();
            GameObject g1 = Instantiate(particle);
            Destroy(g1, 2);
        }
		if (collision.gameObject.tag == "enemy")
		{
            score -= 2;
            Destroy(collision.gameObject);
            textScore.text = "Score:" + score.ToString();
			if (score<=0)
			{
                Application.LoadLevel("Menu");
			}
        }
		if (collision.gameObject.tag=="ground")
		{
            grounded = true;
		}
		else
		{
            grounded = false;
		}
        
	}
	// Update is called once per frame
	void Update()
    {
        if (!isGameOver)
        {

            if (Input.GetKey(KeyCode.LeftArrow))
            {
                player.SetBool("running",true);//trạng thái chạy bằng true
                player.SetBool("dead", false);
                player.SetBool("die", false);
                //di chuyển
                gameObject.transform.Translate(Vector3.left * speed * Time.deltaTime);
                //quay đầu
                if(gameObject.transform.localScale.x>0)//xác định tiến hoặc lùi
                {
                    gameObject.transform.localScale =
                        new Vector3(gameObject.transform.localScale.x * -1,
                                gameObject.transform.localScale.y,
                                gameObject.transform.localScale.z);
                }    
            }
            else if (Input.GetKey(KeyCode.RightArrow))
            {
                player.SetBool("running", true);//trạng thái chạy bằng true
                player.SetBool("dead", false);
                player.SetBool("die", false);
                //di chuyển
                gameObject.transform.Translate(Vector3.right * speed * Time.deltaTime);
                //quay đầu
                if (gameObject.transform.localScale.x < 0)//xác định tiến hoặc lùi
                {
                    gameObject.transform.localScale =
                        new Vector3(gameObject.transform.localScale.x * -1,
                                gameObject.transform.localScale.y,
                                gameObject.transform.localScale.z);
                }
            }
            else if (Input.GetKey(KeyCode.Space) && grounded==true)
            {
                    grounded = false;
                    player.SetBool("running", true);//trạng thái chạy bằng true
                    player.SetBool("dead", false);
                    player.SetBool("die", false);
                    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x, jumpHeight);
                
                
            }
            else
            {
                player.SetBool("running", false);//trạng thái chạy bằng true
                player.SetBool("dead", true);
                player.SetBool("die", false);
            }
        }
        
    }
}
