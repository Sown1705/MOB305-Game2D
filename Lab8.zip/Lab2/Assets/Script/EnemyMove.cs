﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{
    // Start is called before the first frame update
    // Start is called before the first frame update
    private Rigidbody2D enemy;
    private bool left = false;
    void Start()
    {
        enemy = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float kc = 0f;
        if (left == true)
        {
            kc = 2f;

        }
        else
        {
            kc = -2f;

        }
        enemy.velocity = new Vector2(transform.localScale.x, 0) * kc;


    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "trai")
        {
            left = true;
        }
        else
        {
            left = false;
        }
    }
}
