﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    private Transform player;
    // Start is called before the first frame update
    void Start()
    {
        //anh xa 
        player = GameObject.Find("player").transform;//game object ben unity
    }

    // Update is called once per frame
    void Update()
    {
		if (player != null)
		{
                Vector3 pos = transform.position;//lay vi tri character
                pos.x = player.position.x;// camera nhan gia tri theo truc x cua chatacter
                pos.y = player.position.y;// camera nhan gia tri theo truc y cua chatacter
                transform.position = pos;
		}
        
    }
}
